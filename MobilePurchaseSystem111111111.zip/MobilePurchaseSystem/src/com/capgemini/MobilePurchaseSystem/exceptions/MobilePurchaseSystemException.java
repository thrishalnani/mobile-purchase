package com.capgemini.MobilePurchaseSystem.exceptions;

public class MobilePurchaseSystemException extends Exception{
	public  MobilePurchaseSystemException (String msg){
		super(msg);
	}
}
