package com.capgemini.MobilePurchaseSystem.dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.capgemini.MobilePurchaseSystem.dto.CustomerDto;
import com.capgemini.MobilePurchaseSystem.exceptions.MobilePurchaseSystemException;
import com.capgemini.MobilePurchaseSystem.util.DBConnection;

public class MobilePurchaseSystemDaoImpl implements IMobilePurchaseSystemDao {

	CustomerDto customerMps = new CustomerDto();
	private Logger logger = Logger.getLogger(MobilePurchaseSystemDaoImpl.class);

	public MobilePurchaseSystemDaoImpl() {
		PropertyConfigurator.configure("log4j.properties");
	}

	@Override
	public CustomerDto mobilePurchaseSystem(CustomerDto customerMps)
			throws MobilePurchaseSystemException {

		logger.info("Customer registration started");
		Connection con;
		PreparedStatement insertStmt = null;
		con = DBConnection.getConnection();
		try {
			java.util.Date udate = customerMps.getPurchaseDate();
			java.sql.Date sdate = new java.sql.Date(udate.getTime());

			insertStmt = con.prepareStatement(IQueryMapper.INSERT_QUERY);
			// insertStmt.setString(1, customerMps.getPurchaseId());
			insertStmt.setString(1, customerMps.getCustomerName());
			insertStmt.setString(2, customerMps.getMailId());
			insertStmt.setString(3, customerMps.getPhoneNumber());
			insertStmt.setDate(4, sdate);
			insertStmt.setLong(5, customerMps.getMobileId());
			int result = insertStmt.executeUpdate();
			if (result != 1) {
				throw new MobilePurchaseSystemException("Sorry not inserted!!!");
			} else {
				insertStmt=con.prepareStatement(IQueryMapper.Get_updateQuantity);
				insertStmt.setLong(1,customerMps.getMobileId());
				result = insertStmt.executeUpdate();
				con.commit();
			}
		} catch (SQLException | NullPointerException e) {
			e.printStackTrace();
		}
		return customerMps;
	}

	public int getPID() throws MobilePurchaseSystemException, SQLException {
		Connection conn = null;
		PreparedStatement preparedStatement = null;
		ResultSet resultSet = null;
		int purchaseID = 0;

		try {
			conn = DBConnection.getConnection();
			preparedStatement = conn.prepareStatement(IQueryMapper.GET_PID);
			resultSet = preparedStatement.executeQuery();

			if (resultSet.next()) {
				purchaseID = resultSet.getInt(1);
			}

		} catch (MobilePurchaseSystemException e) {
			throw new MobilePurchaseSystemException(
					"soory not fetching the Purchase Id");

		}
		return purchaseID;
	}

	// for mobile id
	public ArrayList<Long> getMobileId() throws SQLException,
			MobilePurchaseSystemException {
		Connection conn = null;
		PreparedStatement preparedStatement = null;
		ResultSet resultSet = null;
		ArrayList<Long> list = new ArrayList<Long>();

		try {
			conn = DBConnection.getConnection();
			preparedStatement = conn
					.prepareStatement(IQueryMapper.GET_MobileId);
			resultSet = preparedStatement.executeQuery();

			while (resultSet.next()) {
				list.add(resultSet.getLong("mobileid"));
			}

		} catch (MobilePurchaseSystemException e) {
			throw new MobilePurchaseSystemException(
					"soory not fetching the Mobile Id");

		}
		return list;
	}

	// list mobiles
	public ArrayList<CustomerDto> getAllMobiles()
			throws MobilePurchaseSystemException {
		Connection conn;
		ResultSet resultSet = null;
		PreparedStatement preparedStatement = null;
		ArrayList<CustomerDto> customerList = new ArrayList<CustomerDto>();
		try {
			conn = DBConnection.getConnection();
			preparedStatement = conn
					.prepareStatement(IQueryMapper.ALL_MobileDetails);
			resultSet = preparedStatement.executeQuery();

			while (resultSet.next()) {
				CustomerDto bean = new CustomerDto();
				bean.setMobileId(resultSet.getInt(1));
				bean.setMobileName(resultSet.getString(2));
				bean.setPrice(resultSet.getInt(3));
				bean.setQuantity(resultSet.getInt(4));
				customerList.add(bean);
			}
		} catch (MobilePurchaseSystemException e) {
			throw new MobilePurchaseSystemException("sorry not updated");
		} catch (SQLException e) {
			throw new MobilePurchaseSystemException("sorry not updated");
		}
		return customerList;
	}

	// mobiles within the range
	public ArrayList<CustomerDto> getSearchedMobiles(int min, int max) {
		ArrayList<CustomerDto> mlist = new ArrayList<CustomerDto>();
		Connection conn;
		PreparedStatement preparedsStatement;

		try {
			conn = DBConnection.getConnection();
			preparedStatement = conn
					.prepareStatement(IQueryMapper.Get_SearchedMobiles);
			preparedStatement.setInt(1, min);
			preparedStatement.setInt(2, max);
			ResultSet set = preparedStatement.executeQuery();
			while (set.next()) {
				CustomerDto bin = new CustomerDto();
				bin.setMobileId(set.getInt(1));
				bin.setMobileName(set.getString(2));
				bin.setPrice(set.getLong(3));
				bin.setQuantity(set.getInt(4));
				mlist.add(bin);
			}
			preparedStatement.close();
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}

		return mlist;
	}

	public boolean isThere(long mobileId) {
		Connection conn;
		PreparedStatement preparedStatement;
		int mobiles=0;
		try {
			conn = DBConnection.getConnection();
			preparedStatement = conn
					.prepareStatement(IQueryMapper.Get_Quantity);
			preparedStatement.setLong(1, mobileId);
			ResultSet set = preparedStatement.executeQuery();
			while (set.next()) {
				mobiles=set.getInt(1); 
			}
			if(mobiles > 0){
				return true;
			}
		}
		catch (Exception e) {
			System.out.println(e.getMessage());
		}
		return false;
	}

}
