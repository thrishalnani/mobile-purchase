package com.capgemini.MobilePurchaseSystem.dao;

import java.util.ArrayList;

import com.capgemini.MobilePurchaseSystem.dto.CustomerDto;
import com.capgemini.MobilePurchaseSystem.exceptions.MobilePurchaseSystemException;

public interface IMobilePurchaseSystemDao {

	
	public CustomerDto mobilePurchaseSystem(CustomerDto mps)throws MobilePurchaseSystemException;
	public ArrayList<CustomerDto> getAllMobiles()
			throws MobilePurchaseSystemException;
	public ArrayList<CustomerDto> getSearchedMobiles(int min, int max);
}


