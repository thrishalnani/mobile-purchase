package com.capgemini.MobilePurchaseSystem.service;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.capgemini.MobilePurchaseSystem.dto.CustomerDto;
import com.capgemini.MobilePurchaseSystem.exceptions.MobilePurchaseSystemException;

public interface IMobilePurchaseSystemService {
	
	public CustomerDto mobilePurchaseSystem(CustomerDto cusdto) throws MobilePurchaseSystemException;
	
	 boolean ValidateCustomerName(String custerName);
	 boolean ValidateMailId(String mailId);
	 boolean ValidatePhoneNumber(String phoneNum);
	 boolean ValidateMobileId(long mobileId);
	 boolean ValidatePurchaseId(String purchaseId);
	//abstract boolean ValidatePurchaseDate();
	 public int getPID() throws MobilePurchaseSystemException, SQLException;
	 public ArrayList<Long> getMobileId() throws SQLException, MobilePurchaseSystemException;
	 public ArrayList<CustomerDto> getAllMobiles()throws MobilePurchaseSystemException;
	 public ArrayList<CustomerDto> getSearchedMobiles(int min, int max);

}
